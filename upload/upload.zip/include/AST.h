//
// Created by lyt on 2019/11/15.
//

#ifndef UNIVERSALCOMPILER_AST_H
#define UNIVERSALCOMPILER_AST_H

namespace ucc
{

	enum AstType
	{

	};

	class AstNode
	{
	};

	class AstAssignNode : public AstNode
	{
	};

	class AstValuableNode : public AstNode
	{
	};

	class AstOptNode : public AstValuableNode
	{
	};



}

#endif //UNIVERSALCOMPILER_AST_H