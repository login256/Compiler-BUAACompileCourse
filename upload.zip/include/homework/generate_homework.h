//
// Created by lyt on 2019/11/16.
//

#ifndef UNIVERSALCOMPILER_GENERATE_HOMEWORK_H
#define UNIVERSALCOMPILER_GENERATE_HOMEWORK_H

namespace generate_homework
{
	int generate_main();
}

#endif //UNIVERSALCOMPILER_GENERATE_HOMEWORK_H
