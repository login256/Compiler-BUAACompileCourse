#include "include/homework/error_homework.h"

int main(int argc, char **args)
{
	error_main();
}