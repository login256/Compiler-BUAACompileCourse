#include "include/homework/generate_homework.h"

int main(int argc, char **args)
{
	generate_homework::generate_main();
}